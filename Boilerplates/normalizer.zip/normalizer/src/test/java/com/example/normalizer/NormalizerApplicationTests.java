package com.example.normalizer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NormalizerApplicationTests {

	@Test
	void contextLoads() {
	}

}
