package com.example.normalizer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NormalizerApplication {

	public static void main(String[] args) {
		SpringApplication.run(NormalizerApplication.class, args);
	}

}
