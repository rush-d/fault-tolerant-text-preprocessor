package com.example.tokenizer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TokenizerApplication {

	public static void main(String[] args) {
		SpringApplication.run(TokenizerApplication.class, args);
	}

}
